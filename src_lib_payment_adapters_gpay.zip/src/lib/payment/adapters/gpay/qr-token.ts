import {
  buildGPayQrTokenUrl,
  getGPayQrConfig,
  type GPayQrTokenStrategy,
} from "./qr-config";
import { GPayError } from "./errors";
import {
  getCachedGPayQrToken,
  setCachedGPayQrToken,
} from "./qr-token-cache";
import type {
  GPayLegacyQrTokenResponse,
  GPayQrAccessToken,
  GPayQrTokenResult,
} from "./qr-types";
import { getGPayAccessToken } from "./token";
import { gpayFetch } from "./debug";

function isRecord(
  value: unknown,
): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function parseLegacyResponse(
  value: unknown,
): GPayLegacyQrTokenResponse {
  if (!isRecord(value)) {
    throw new GPayError({
      code: "GPAY_QR_TOKEN_RESPONSE_INVALID",
      message:
        "GPay QR Token API trả dữ liệu không hợp lệ.",
      details: value,
    });
  }

  return value as GPayLegacyQrTokenResponse;
}

async function requestLegacyQrToken():
Promise<GPayQrAccessToken> {
  const config = getGPayQrConfig();

  const result = await gpayFetch(
    buildGPayQrTokenUrl(config),
    {
      operation: "gpay.qr.token.legacy",
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        merchant_code: config.merchantCode,
        password: config.password,
      }),
      cache: "no-store",
      timeoutMs: config.requestTimeoutMs,
    },
  );

  const payload = parseLegacyResponse(result.body);
  const token = payload.response?.token;
  const expiresAt = payload.response?.expired_at;

  if (!result.response.ok || !token || !expiredAt) {
    throw new GPayError({
      code: "GPAY_QR_TOKEN_REQUEST_FAILED",
      status: result.response.status,
      message:
        payload.meta?.msg ??
        payload.meta?.message ??
        "Không thể lấy QR Payment token từ GPay.",
      details: {
        meta: payload.meta,
      },
    });
  }

  const normalized: GPayQrAccessToken = {
    accessToken: token,
    tokenType: "Bearer",
    expiredAt,
    obtainedAt: new Date().toISOString(),
    strategy: "legacy",
  };

  setCachedGPayQrToken(normalized);
  return normalized;
}

async function requestOpenApiQrToken(
  forceRefresh: boolean,
): Promise<GPayQrTokenResult> {
  const result = await getGPayAccessToken({
    forceRefresh,
  });

  const normalized: GPayQrAccessToken = {
    accessToken: result.token.accessToken,
    tokenType: result.token.tokenType,
    expiresAt: result.token.expiresAt,
    obtainedAt: result.token.obtainedAt,
    strategy: "openapi",
    scope: result.token.scope,
  };

  return {
    token: normalized,
    cached: result.cached,
  };
}

export async function getGPayQrToken(
  options: {
    forceRefresh?: boolean;
    strategy?: GPayQrTokenStrategy;
  } = {},
): Promise<GPayQrTokenResult> {
  const strategy =
    options.strategy ??
    getGPayQrConfig().tokenStrategy;

  if (strategy === "openapi") {
    return requestOpenApiQrToken(
      options.forceRefresh === true,
    );
  }

  if (!options.forceRefresh) {
    const cached = getCachedGPayQrToken("legacy");

    if (cached) {
      return {
        token: cached,
        cached: true,
      };
    }
  }

  return {
    token: await requestLegacyQrToken(),
    cached: false,
  };
}
