import {
  NextResponse,
} from "next/server";

import {
  createGPayQrPayment,
  getGPayQrConfig,
  isGPayError,
} from "@/lib/payment/adapters/gpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface CreateQrTestBody {
  amount?: number;
  billId?: string;
  description?: string;
}

function authorized(
  request: Request,
): boolean {
  const expected =
    process.env
      .GPAY_SANDBOX_TEST_API_KEY
      ?.trim();

  return Boolean(
    expected &&
    request.headers
      .get("x-ysim-test-key")
      ?.trim() === expected,
  );
}

export async function POST(
  request: Request,
) {
  if (!authorized(request)) {
    return NextResponse.json(
      {
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message:
            "Không được phép gọi API test tạo QR.",
        },
      },
      {
        status: 401,
      },
    );
  }

  try {
    const body =
      (await request.json()) as
        CreateQrTestBody;

    const config =
      getGPayQrConfig();

    const amount =
      body.amount ?? 10_000;

    const billId =
      body.billId?.trim() ||
      `YSIMSBX${Date.now()}`;

    /*
     * Nội dung chuyển khoản nên chứa
     * chính mã bill/order để đối chiếu webhook.
     */
    const description =
      body.description?.trim() ||
      billId;

    const payment =
      await createGPayQrPayment({
        merchantCode:
          config.merchantCode,

        terminalId:
          config.terminalId,

        qrType:
          config.qrType,

        accountName:
          config.accountName,

        amount,

        sourceOfFund:
          config.sourceOfFund,

        billId,

        storeCode:
          config.storeCode,

        description,
      });

    return NextResponse.json({
      success: true,
      payment,
    });
  } catch (error) {
    if (isGPayError(error)) {
      console.error(
        "GPay QR test failed:",
        {
          code: error.code,
          status: error.status,
          message: error.message,
          details: error.details,
        },
      );

      return NextResponse.json(
        {
          success: false,
          error: {
            code: error.code,
            message: error.message,
            status: error.status,
            details: error.details,
          },
        },
        {
          status:
            error.status &&
            error.status >= 400 &&
            error.status <= 599
              ? error.status
              : 502,
        },
      );
    }

    console.error(
      "Unexpected QR test error:",
      error,
    );

    return NextResponse.json(
      {
        success: false,
        error: {
          code:
            "INTERNAL_SERVER_ERROR",
          message:
            "Không thể tạo QR thử nghiệm.",
        },
      },
      {
        status: 500,
      },
    );
  }
}
